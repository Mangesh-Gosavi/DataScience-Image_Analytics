

function Skill() {
 
    return (
      <>
      <div>
        <h1>Skill Page</h1>
      </div>  
      </>
    );
  }
  
  export default Skill;
  