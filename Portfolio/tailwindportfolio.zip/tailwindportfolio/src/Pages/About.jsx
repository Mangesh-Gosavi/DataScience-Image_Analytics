function About() {
  return (
    <>
      <div className="flex items-center justify-center bg-red-300">
        <h3>
          Hi, I'm Mangesh Namdeo Gosavi, a full-stack developer and design
          enthusiast. Want to be a web or software developer. I feel comfortable
          working with technologies like
          HTML,CSS,JavaScript,React,Tailwind,Node.js, MySQL,Figma and many other
          technologies in the web ecosystem. I love programming, design, user
          interfaces and that's what I'm passionate about. Aside from work, I'm
          was a national level sports player in game name Handball.Currently,
          I'm working on a mern project. In addition, I'm learning ML for
          automation.
        </h3>
      </div>
    </>
  );
}

export default About;
