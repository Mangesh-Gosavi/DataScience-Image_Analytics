import { Link } from "react-router-dom";


function Header() {

    return (
      <>
      <div className="grid grid-cols-2 text-white h-full items-center font-bold">
       <h2 className="ml-6">Mangesh</h2>
       <div className="flex justify-evenly list-none">
          <Link to='/'><li>About</li></Link>
          <Link to='/Skill'><li>Skills</li></Link>
          <Link to='/Project'><li>Projects</li></Link>
          <Link to='/Contact'><li>Contact</li></Link>
       </div>
      </div>  
      </>
    );
  }
  
  export default Header;
  